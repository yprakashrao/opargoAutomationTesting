package com.bddCucumber.DataProviders;

import java.util.List;

import com.bddCucumber.Managers.FileReaderManager;

public class JsonDataReader {
	
	public final String customerFilePath = FileReaderManager.getInstance().getConfigReader().getTestDataResourcePath() + "jsonfilename.json";

}
