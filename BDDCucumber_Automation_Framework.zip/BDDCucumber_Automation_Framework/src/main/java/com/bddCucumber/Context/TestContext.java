package com.bddCucumber.Context;

import com.bddCucumber.Managers.BaseClass;

public class TestContext {
	
	public BaseClass baseClass;
	public ScenarioContext scenarioContext;
	
	public TestContext(){
		baseClass = new BaseClass();
		scenarioContext = new ScenarioContext();
	}
	
	public BaseClass getWebDriverManager() {
		return baseClass;
	}
	
	public ScenarioContext getScenarioContext() {
		return scenarioContext;
	}

}
