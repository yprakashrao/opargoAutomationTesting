package com.bddCucumber.Managers;

import com.bddCucumber.DataProviders.ConfigFileReader;
import com.bddCucumber.DataProviders.JsonDataReader;

public class FileReaderManager {
	
	public static FileReaderManager fileReaderManager = new FileReaderManager();
	public static ConfigFileReader configFileReader;
	public static JsonDataReader jsonDataReader;
	
	public FileReaderManager() {
	}
	
	 public static FileReaderManager getInstance() {
	      return fileReaderManager;
	 }
	 
	 public ConfigFileReader getConfigReader() {
		 return (configFileReader == null) ? configFileReader = new ConfigFileReader() : configFileReader;
	 }
	 
	 public JsonDataReader getJsonReader(){
		 return (jsonDataReader == null) ? jsonDataReader = new JsonDataReader() : jsonDataReader;
	}

}
