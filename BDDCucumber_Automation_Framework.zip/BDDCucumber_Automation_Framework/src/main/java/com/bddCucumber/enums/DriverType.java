package com.bddCucumber.enums;

public enum DriverType {
	
	CHROME,
	FIREFOX,
	MSEDGE,
	INTERNETEXPLORER


}
