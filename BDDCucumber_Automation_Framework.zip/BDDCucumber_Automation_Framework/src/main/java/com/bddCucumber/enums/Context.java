package com.bddCucumber.enums;

public enum Context {
	PRODUCT_NAME;
}
