package com.bddCucumber.enums;

public enum EnvironmentType {
	LOCAL,
	REMOTE,
}
