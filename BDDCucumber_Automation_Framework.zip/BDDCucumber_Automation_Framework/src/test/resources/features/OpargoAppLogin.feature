@Opargo
Feature: Automate Opargo Application
  Description: User Able to Automate The Opargo Application Functionality

  @Opargo_Login
  Scenario: Automate The Login Functionality
    Given User Able to Navigate The UAT or QA Enviroment Opargo Application URL
    Then User Able to Enter The Username
    When User Able to Enter The Password
    #And User Able to Select The I Am Not Robot Captcha
    And User Able to Click on Login Button
    
  @SmartReach_createNewProgram
  Scenario: Automate the SmartReach Functionality
    Given User Able to Click on SmartReach Tab
    When User Able to Click on Create New Program
    Then User Able to Enter Program Name
    And User Able to Select The Goal of Program in The Dropdown
    And User Able to Select The Text Time in The Dropdown
    And User Able to Enter The Text Allocation
    And User Able to Click on Create Program Button

    And User Able to Search The Created Programe in The SmartReach
    And User Able to Select The Created SmartReach Programe
    And User Able to Click on Programe Details Option in the Actions Tab
    And User Able to Click on Criteria Option
    And User Able to Select on Criteria Options
    And User Able to Click on Next Button
    And User Able to Edit The Appointment Type and Select on Appointment Type
    And User Able to Click on Save Button
    And User Able to Edit Gender and Select Gender
    And User Able to Click on Again Save Button
    And User Able to Edit Insurence Plans and Select Insurence Plans
    And User Able to Click on Again Save BUtton

    And User Able to Click on Scheduled Action Button and Select Schedule Action
    And User Able to Click on Next Button in Schdeduled Action Page
    And User Able to Edit The Location and Select The Location
    And User Able to Click on Save Option
    And User Able to Click on Text Message Button
    And User Able to Enter The Text After Link
    And User Able to Click on Close Button
    And User Able to Click on Save Button in SamrtEngine Page

    And User Able to Search The Created Programe in The SmartReach
    And User Able to Click and Change Status of Created Programe

    And User Able to Search The Created Programe in The SmartReach
    And User Able to Select The Programe Info Option in The Action Tab
    #And User Able to Enter The Text After Link
    And User Able to Click on Edit Programe Button

    And User Able to Search The Created Programe in The SmartReach
    And User Able to Delete The Created Programe Option in The Action Tab




