package com.bddCucumber.StepDefinitions;

import java.io.IOException;

import com.bddCucumber.Managers.BaseClass;
import com.bddCucumber.Managers.SeleniumUtils;
import com.bddCucumber.PageActions.OpargoApp_PageActions;

import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class OpargoApp_StepDefinitions extends BaseClass{
	/***************Login Functionality Flow***************************/
	@Given("^User Able to Navigate The UAT or QA Enviroment Opargo Application URL$")
	public static void userAbleToNavigateTheUATOrQAEnvironmentOpargoApplicationURL() throws IOException{
		OpargoApp_PageActions.userAbleToNavigateTheUATOrQAEnvironmentOpargoApplicationURL();
	}
	@Then("^User Able to Enter The Username$")
	public static void userAbleToEnterTheUsername() throws IOException {
		OpargoApp_PageActions.userAbleToEnterTheUsername();
	}
	@When("^User Able to Enter The Password$")
	public static void userAbleToEnterThePassword() throws IOException {
		OpargoApp_PageActions.userAbleToEnterThePassword();
	}
	@And("^User Able to Select The I Am Not Robot Captcha$")
	public static void userAbleToSelectTheIAmNotRobotCaptcha() throws IOException {
		OpargoApp_PageActions.userAbleToSelectTheIAmNotRobotCaptcha();
	}
	@And("^User Able to Click on Login Button$")
	public static void userAbleToClickOnLoginButton() throws IOException {
		OpargoApp_PageActions.userAbleToClickOnLoginButton();
	}
	
	/*************SmartREach Functionality FLow****************************/
	@Given("^User Able to Click on SmartReach Tab$")
    public static void userAbleToClickOnSmartReachTab() {
		OpargoApp_PageActions.userAbleToClickOnSmartReachTab();
    }
    @When("^User Able to Click on Create New Program$")
    public static void userAbleToClickOnCreateNewPrograme() {
    	OpargoApp_PageActions.userAbleToClickOnCreateNewPrograme();
    }
    @Then("^User Able to Enter Program Name$")
    public static void userAbleToEnterProgramName() throws IOException {
    	OpargoApp_PageActions.userAbleToEnterProgramName();
    }
    @And("^User Able to Select The Goal of Program in The Dropdown$")
    public static void userAbleToSelectTheGoalOfProgrameInTheDropdon() {
    	OpargoApp_PageActions.userAbleToSelectTheGoalOfProgrameInTheDropdon();
    }
    @And("^User Able to Select The Text Time in The Dropdown$")
    public static void userAbleToSelectTheTextTimeInTheDropdown() {
    	OpargoApp_PageActions.userAbleToSelectTheTextTimeInTheDropdown();
    }
    @And("^User Able to Enter The Text Allocation$")
    public static void userAbleToEnterTheTextAllocation() throws IOException {
    	OpargoApp_PageActions.userAbleToEnterTheTextAllocation();
    }
    @And("^User Able to Click on Create Program Button$")
    public static void userAbleToClickOnCreateProgrameButton() {
    	OpargoApp_PageActions.userAbleToClickOnCreateProgrameButton();
    }
    @And("^User Able to Search The Created Programe in The SmartReach$")
    public static void userAbleToSearchTheCreatedProgrameInTheSmartReach() throws IOException {
    	OpargoApp_PageActions.userAbleToSearchTheCreatedProgrameInTheSmartReach();
    }
    @And("^User Able to Select The Created SmartReach Programe$")
    public static void userAbleToSelectTheCreatedSmartReachPrograme() {
    	OpargoApp_PageActions.userAbleToSelectTheCreatedSmartReachPrograme();
    }
    @And("^User Able to Click on Programe Details Option in the Actions Tab$")
    public void userAbleToClickOnProgrameDetailsOptionInTheActionsTab() {
    	OpargoApp_PageActions.userAbleToClickOnProgrameDetailsOptionInTheActionsTab();
    }
    @And("^User Able to Click on Criteria Option$")
    public void userAbleToClickOnCriteriaOption() {
    	OpargoApp_PageActions.userAbleToClickOnCriteriaOption();
    }
    @And("^User Able to Select on Criteria Options$")
    public void userAbleToSelectOnCriteriaOptions() {
    	OpargoApp_PageActions.userAbleToSelectOnCriteriaOptions();
    }
    @And("^User Able to Click on Next Button$")
    public void userAbleToClickOnNextButton() {
    	OpargoApp_PageActions.userAbleToClickOnNextButton();
    }
    @And("^User Able to Edit The Appointment Type and Select on Appointment Type$")
    public void userAbleToEditTheAppointmentTypeAndSelectOnAppointmentType() {
    	OpargoApp_PageActions.userAbleToEditTheAppointmentTypeAndSelectOnAppointmentType();
    }
    @And("^User Able to Click on Save Button$")
    public void userAbleToClickOnSaveButton() {
    	OpargoApp_PageActions.userAbleToClickOnSaveButton();
    }
    @And("^User Able to Click on Save Button in SamrtEngine Page$")
    public void userAbleToClickOnSAveButtonInSmartEnginePage() {
    	OpargoApp_PageActions.userAbleToClickOnSAveButtonInSmartEnginePage();
    }
    @And("^User Able to Edit Insurence Plans and Select Insurence Plans$")
    public void userAbleToEditInsurencePlansAndSelectInsurencePlans() {
    	OpargoApp_PageActions.userAbleToEditInsurencePlansAndSelectInsurencePlans();
    }
    @And("^User Able to Edit Gender and Select Gender$")
    public void userAbleToEditGenderAndSelectGender() {
    	OpargoApp_PageActions.userAbleToEditGenderAndSelectGender();
    }
    @And("^User Able to Click on Scheduled Action Button and Select Schedule Action$")
    public void userAbleToClickOnScheduledActionButtonAndSelectScheduleAction() {
    	OpargoApp_PageActions.userAbleToClickOnScheduledActionButtonAndSelectScheduleAction();
    }
    @And("^User Able to Edit The Location and Select The Location$")
    public void userAbleToEditTheLocationAndSelectTheLocation() {
    	OpargoApp_PageActions.userAbleToEditTheLocationAndSelectTheLocation();
    }
    @And("^User Able to Click on Save Option$")
    public void userAbleToClickOnSaveOption() {
    	OpargoApp_PageActions.userAbleToClickOnSaveOption();
    }
    @And("^User Able to Click on Text Message Button$")
    public void userAbleToClickOnTextMessageButton() {
    	OpargoApp_PageActions.userAbleToClickOnTextMessageButton();
    }
    @And("^User Able to Enter The Text After Link$")
    public void userAbleToEnterTheTextAfterLinkTextarea() throws IOException {
    	OpargoApp_PageActions.userAbleToEnterTheTextAfterLinkTextarea();
    }
    @And("^User Able to Click on Close Button$")
    public void userAbleToClickOnCloseButton() {
    	OpargoApp_PageActions.userAbleToClickOnCloseButton();
    }
    @And("^User Able to Click and Change Status of Created Programe$")
    public void userAbleToClickAndChangeStatusOfCreatedPrograme() {
    	OpargoApp_PageActions.userAbleToClickAndChangeStatusOfCreatedPrograme();
    }
    @And("^User Able to Select The Programe Info Option in The Action Tab$")
    public void userAbleToSelectTheProgrameInfoOptionInTheActionTab() {
    	OpargoApp_PageActions.userAbleToSelectTheProgrameInfoOptionInTheActionTab();
    }
    @And("^User Able to Click on Edit Programe Button$")
    public void userAbleToClickOnEditProgrameButton() {
    	OpargoApp_PageActions.userAbleToClickOnEditProgrameButton();
    }
    @And("^User Able to Delete The Created Programe Option in The Action Tab$")
    public void userAbleToDeleteTheCreatedProgrameInTheActionTab() {
    	OpargoApp_PageActions.userAbleToDeleteTheCreatedProgrameInTheActionTab();
    }
    @And("^User Able to Click on Next Button in Schdeduled Action Page$")
    public void userAbleToClickOnNextButtonInScheduledActionPage() {
    	OpargoApp_PageActions.userAbleToClickOnNextButtonInScheduledActionPage();
    }
    @And("^User Able to Click on Again Save Button$")
    public void userAbleToClickOnAgainSaveButton() {
    	OpargoApp_PageActions.userAbleToClickOnAgainSaveButton();
    }
    @And("^User Able to Click on Again Save BUtton$")
    public void userAbleTOClickOnAgainSAveButton() {
    	OpargoApp_PageActions.userAbleTOClickOnAgainSAveButton();
    }
   
    
    
}