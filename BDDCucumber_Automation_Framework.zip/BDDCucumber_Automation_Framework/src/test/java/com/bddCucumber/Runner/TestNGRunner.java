package com.bddCucumber.Runner;

import org.junit.After;
import org.junit.Before;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import cucumber.api.testng.AbstractTestNGCucumberTests;
import cucumber.api.testng.CucumberFeatureWrapper;
import cucumber.api.testng.TestNGCucumberRunner;
import io.cucumber.junit.CucumberOptions;

@CucumberOptions(features={"src/test/resources/features"},
                 glue={"com.bddCucumber.StepDefinitions","com.bddCucumber.Hooks"},
                 dryRun = false, monochrome = true, 
                 plugin={"pretty","html:target/cucumberReports/Report.html",
                         "json:target/cucumberReports/Report.json",
                         "junit:target/cucumberReports/Report.xml",
                         "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"},
                 tags="@Opargo_Login11")
public class TestNGRunner extends AbstractTestNGCucumberTests {
	
	@DataProvider(parallel = false)
	public Object[][] scenarios() {
		return super.scenarios();
	}

	@BeforeSuite
    public void beforeSuite() {
        System.out.println("================ BEFORE SUITE ================");
    }

    @AfterSuite
    public void afterSuite() {
        System.out.println("================ AFTER SUITE ================");
    }

  
}
