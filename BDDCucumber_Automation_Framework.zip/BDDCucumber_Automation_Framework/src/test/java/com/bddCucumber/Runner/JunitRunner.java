package com.bddCucumber.Runner;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import java.util.logging.Logger;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.RunWith;
import org.junit.runner.notification.Failure;
import org.junit.runner.notification.RunListener;

@RunWith(Cucumber.class)
@CucumberOptions(features={"src/test/resources/features"},
                 glue={"com.bddCucumber.StepDefinitions","com.bddCucumber.Hooks"},
                 dryRun = false,
                 plugin={"pretty","html:target/cucumberReports/Report.html",
                         "json:target/cucumberReports/Report.json",
                         "junit:target/cucumberReports/Report.xml",
                         "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"},
                 tags="")
public class JunitRunner {
	
	private static final Logger LOGGER = Logger.getLogger(JunitRunner.class.getName());

	public JunitRunner() {
	JUnitCore junit = new JUnitCore();
	junit.addListener(new CustomTestListener());
	Result result = junit.run(JunitRunner.class);
	printTestResults(result);
	}

	static class CustomTestListener extends RunListener {
	@Override
	public void testRunStarted(org.junit.runner.Description description) {
	LOGGER.info("BDD Test execution started: " + description.getDisplayName());
	}

	@Override
	public void testStarted(org.junit.runner.Description description) {
	LOGGER.info("Starting scenario: " + description.getMethodName());
	}

	@Override
	public void testFinished(org.junit.runner.Description description) {
	LOGGER.info("Completed scenario: " + description.getMethodName());
	}

	@Override
	public void testFailure(Failure failure) {
	LOGGER.severe("Scenario failed: " + failure.getTestHeader() +
	"\nException: " + failure.getException());
	}

	@Override
	public void testIgnored(org.junit.runner.Description description) {
	LOGGER.warning("Scenario ignored: " + description.getMethodName());
	}
	}

	private static void printTestResults(Result result) {
	LOGGER.info("\n=== BDD Test Execution Summary ===");
	LOGGER.info("Total Scenarios Run: " + result.getRunCount());
	LOGGER.info("Scenarios Passed: " + (result.getRunCount() - result.getFailureCount()));
	LOGGER.info("Scenarios Failed: " + result.getFailureCount());
	LOGGER.info("Scenarios Ignored: " + result.getIgnoreCount());
	LOGGER.info("Execution Time: " + result.getRunTime() + "ms");

	if (!result.getFailures().isEmpty()) {
	LOGGER.severe("\n=== Failure Details ===");
	for (Failure failure : result.getFailures()) {
	LOGGER.severe(failure.getTestHeader() + ": " + failure.getMessage());
	LOGGER.severe("Stack Trace: " + failure.getTrace());
	}
	}

	LOGGER.info("\nTest Suite " + (result.wasSuccessful() ? "PASSED" : "FAILED"));
	}
}
