package com.bddCucumber.PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class OpargoApp_PageObjects {
	/**************************************************************/
	public OpargoApp_PageObjects(final WebDriver driver) {
		PageFactory.initElements(driver, this);}
	/**************************************************************/

	/******************Login Functionality WebElements*************/
	@FindBy(xpath="//input[@name='username']")
	public WebElement enterusername;
	
	@FindBy(xpath="//input[@name='password']")
	public WebElement enterpassword;
	
	@FindBy(xpath="//button[text()='Login']")
	public WebElement IamNotRobot;
	
	@FindBy(xpath="//button[text()='Login']")
	public WebElement loginButton;
	
	/******************Login Functionality WebElements*************/
	@FindBy(xpath="//*[text()='SmartReach']")
	public WebElement clicksmartReachTab;
	
	@FindBy(xpath="//*[text()='Create New Program']")
	public WebElement clickOnCreateNewProgram;
	
    @FindBy(xpath="//input[@placeholder='Program Name']")
	public WebElement enterProgrameName;		
    		
    @FindBy(xpath="//*[@id=\"mat-mdc-dialog-0\"]/div/div/app-createprogrammodal/div/div/div[2]/form/div[1]/div/div[3]/div/div/select")
	public WebElement clickGoalProgrameDropdown;
    
    @FindBy(xpath="//option[text()=' Annual Visit ']")
	public WebElement selectGoalProgrameDropdown;
    		
    @FindBy(xpath="//*[@id=\"mat-mdc-dialog-0\"]/div/div/app-createprogrammodal/div/div/div[2]/form/div[1]/div/div[4]/div/div/select")
	public WebElement clickTextTimeDropdown;
    
    @FindBy(xpath="//option[text()=' 4AM ']")
	public WebElement selectTextTimeDropdown;
    
    @FindBy(xpath="//*[@id=\"mat-mdc-dialog-0\"]/div/div/app-createprogrammodal/div/div/div[2]/form/div[2]/div/div[1]/div[1]/div[1]/div/input")
	public WebElement enterTextAllocation;
    
    @FindBy(xpath="//button[text()='Create Program']")
	public WebElement clickOnCreatePrograme;
    
    @FindBy(xpath="//input[@placeholder='Search Program']")
	public WebElement SearchTab;
    
    @FindBy(xpath="/html/body/div[1]/app-root/app-proactiveadmin/div/div/div/div/div[2]/app-proactivecareengine/div/div[3]/div/table/tbody/tr/td[4]/button/mat-icon")
	public WebElement selectCreatedSamrtREachPrpgrame;
    
    @FindBy(xpath="//*[text()=' Program Details']")
	public WebElement clickonProgrameDetailsOption;
    
    @FindBy(xpath="//a[text()='Criteria']")
	public WebElement clickonCriteriaOption;
    
    @FindBy(xpath="//*[@id=\"selectCriteriaModal\"]/div/div/div[2]/div/div[1]/div/div[2]/div[1]/div/a[3]")
	public WebElement SelectAppointmentTypeOption;
    
    @FindBy(xpath="//*[@id=\"selectCriteriaModal\"]/div/div/div[2]/div/div[1]/div/div[2]/div[1]/div/a[9]")
	public WebElement selectGenderOption;
    
    @FindBy(xpath="//*[@id=\"selectCriteriaModal\"]/div/div/div[2]/div/div[1]/div/div[2]/div[1]/div/a[9]")
	public WebElement selectInsurencePlan;
    
    @FindBy(xpath="//*[@id=\"selectCriteriaModal\"]/div/div/div[2]/div/div[3]/div/div[2]/div[2]/div[2]/a[1]")
	public WebElement clickOnNextButton;
    
    @FindBy(xpath="//*[@id=\"selectActionModal\"]/div/div/div[2]/div[2]/div[2]/div/div[2]/a[1]")
	public WebElement againclickOnNextButton;
    
    @FindBy(xpath="//div[text()='Appointment Type']/following::a[text()=' Edit']")
	public WebElement clickEditAppointmentType;
    
    @FindBy(xpath="//a[text()=' CT HIP LT W WO ']")
	public WebElement selectAppointmentType;
    
    @FindBy(xpath="//a[@class='btn4 me-4']")
	public WebElement ClickonSaveButton;
    
    @FindBy(xpath="//a[@class='btn4 me-4']")
	public WebElement againClickOnSAveBUtton;
    
    @FindBy(xpath="//a[@class='btn4 me-4']")
	public WebElement againclickOnsaveButton;
    
    @FindBy(xpath="//div[text()='Gender']/following::a[text()=' Edit']")
	public WebElement clickEditGender;
    
    @FindBy(xpath="//a[text()=' Male ']")
	public WebElement selectGender;
    
    @FindBy(xpath="//div[text()='Insurance Plan']/following::a[text()=' Edit']")
	public WebElement clickEditInsurencePlans;
    
    @FindBy(xpath="//a[text()=' BLUE CROSS BLUE SHIELD ']")
	public WebElement selectInsurencePlans;
    
    @FindBy(xpath="//a[text()='Scheduled Action']")
	public WebElement clickOnScheduledAcion;
    
    @FindBy(xpath="//a[text()=' Location ']")
	public WebElement selectScheduleAction;
    
    @FindBy(xpath="//*[@id=\"mat-mdc-dialog-1\"]/div/div/app-proactivemodals/div[3]/div/div[2]/div/div[1]/div/div[3]/div/div/div/div[1]/a")
	public WebElement editAppointmentType;
    
    @FindBy(xpath="//a[text()=' Office Visit ']")
	public WebElement selectAppointmentTypeOption;
    
    @FindBy(xpath="//a[@class='btn4 me-4']")
	public WebElement saveOption;
    
    @FindBy(xpath="//div[text()='Location']/following::a[text()=' Edit']")
	public WebElement editLocation;
    
    @FindBy(xpath="//a[text()='  DEPARTMENT ']")
	public WebElement selectLocationInScheduleValues;
    
    @FindBy(xpath="//a[@class='btn4 me-4']")
	public WebElement saveOPtion;
    
    @FindBy(xpath="//a[text()='Text Message']")
	public WebElement clickOnTextMessage;
    
    @FindBy(xpath="//textarea[@placeholder='Enter message text here.']")
	public WebElement enterText;
    
    @FindBy(xpath="//*[@id=\"mat-mdc-dialog-7\"]/div/div/app-messagetextmodal/div/div/div[2]/div[2]/div/div/div/a")
	public WebElement clickcloseButton;
    
    @FindBy(xpath="//a[@class='btn2 ng-star-inserted']")
	public WebElement clickOnSave;
    
    @FindBy(xpath="/html/body/div[1]/app-root/app-proactiveadmin/div/div/div/div/div[2]/app-proactivecareengine/div/div[3]/div/table/tbody/tr/td[3]/div/select")
	public WebElement clickOnStatus;

    @FindBy(xpath="//option[text()=' Active ']")
	public WebElement selectandChangeTheStatus;

    @FindBy(xpath="//*[text()=' Program Info']")
	public WebElement selectTheProgrameInfoOption;

    @FindBy(xpath="//*[@id=\"mat-mdc-dialog-8\"]/div/div/app-editprogrammodal/div/div/div[2]/form/div[2]/div/div[2]/div[1]/button")
	public WebElement EditProgrameButton;

    @FindBy(xpath="//span[text()=' Delete']")
	public WebElement DeleteCreatedePrograme;

    @FindBy(xpath="//span[text()='Yes']")
	public WebElement clickOnYesButton;
		
}
