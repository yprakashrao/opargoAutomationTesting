package com.bddCucumber.Hooks;

import io.cucumber.java.After;
import io.cucumber.java.AfterStep;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.bddCucumber.Context.TestContext;
import com.bddCucumber.Managers.BaseClass;

public class Hooks {
	TestContext testContext;
	BaseClass baseclass;

		public Hooks () {
			testContext = new TestContext();
			baseclass = new BaseClass();
		}
    
    @Before
    public void setUp(){
    	testContext.getWebDriverManager().getDriver();
    }
    /*@After(order=0)
    public void tearDown(){
	   testContext = new TestContext();
	   testContext.getWebDriverManager().quitDriver();
       System.out.println("In Tear down method");
   }
   @After(order=1)
    public void takeScreenshot(Scenario scenario){
        String screenShotName=scenario.getName().toUpperCase().replaceAll(" ","_");
    byte[] srcLocation=((TakesScreenshot)driver).getScreenshotAs(OutputType.BYTES);
    if(scenario.isFailed()) {
        scenario.attach(srcLocation, "image/png", screenShotName);
    }
   }*/
    
    @AfterStep
	public void AddScreenshot(Scenario scenario) throws IOException {
		if (scenario.isFailed()) {
			File sourcePath = ((TakesScreenshot) baseclass.driver).getScreenshotAs(OutputType.FILE);
			byte[] fileContent = FileUtils.readFileToByteArray(sourcePath);
			scenario.attach(fileContent, "image/png", "image");
		}
	}
    
    @After(order = 0)
	public void AfterSteps() {
		//testContext.getWebDriverManager().quitDriver();
	}
}
