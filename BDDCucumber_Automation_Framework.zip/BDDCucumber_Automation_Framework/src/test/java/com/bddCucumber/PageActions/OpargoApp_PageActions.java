package com.bddCucumber.PageActions;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.bddCucumber.Managers.FileReaderManager;
import com.bddCucumber.Managers.SeleniumUtils;
import com.bddCucumber.PageObjects.OpargoApp_PageObjects;

public class OpargoApp_PageActions extends SeleniumUtils {
	/**************************************************************************************/
    static OpargoApp_PageObjects OpargoApp_PageObjects = new OpargoApp_PageObjects(driver);
	public OpargoApp_PageActions(final WebDriver driver) {
		super(driver);}
	/**************************************************************************************/
	
	/***************Login Functionality Flow***********************************************/
	public static void userAbleToNavigateTheUATOrQAEnvironmentOpargoApplicationURL() throws IOException {
		SeleniumUtils.navigateToURL(driver, FileReaderManager.getInstance().getConfigReader().readFromProperties("appURL"));
	}
	public static void userAbleToEnterTheUsername() throws IOException {
		SeleniumUtils.setValueToElement(driver, OpargoApp_PageObjects.enterusername, FileReaderManager.getInstance().getConfigReader().readFromProperties("username"));
	}
	public static void userAbleToEnterThePassword() throws IOException {
		SeleniumUtils.setValueToElement(driver, OpargoApp_PageObjects.enterpassword, FileReaderManager.getInstance().getConfigReader().readFromProperties("password"));
	}
	public static void userAbleToSelectTheIAmNotRobotCaptcha() throws IOException {
		SeleniumUtils.clickElementbyWebElementWithOutSendKeys(driver, OpargoApp_PageObjects.IamNotRobot);
	}
	public static void userAbleToClickOnLoginButton() throws IOException {
		SeleniumUtils.clickElementbyWebElementWithOutSendKeys(driver, OpargoApp_PageObjects.loginButton);
	}

	/*************SmartREach Functionality FLow********************************************/
	public static void userAbleToClickOnSmartReachTab() {
		SeleniumUtils.safeWait(driver, 15);
		SeleniumUtils.clickElementbyWebElementWithOutSendKeys(driver, OpargoApp_PageObjects.clicksmartReachTab);
	}
	public static void userAbleToClickOnCreateNewPrograme() {
		SeleniumUtils.safeWait(driver, 10);
		SeleniumUtils.clickElementbyWebElementWithOutSendKeys(driver, OpargoApp_PageObjects.clickOnCreateNewProgram);
	}
	public static void userAbleToEnterProgramName() throws IOException {
		SeleniumUtils.safeWait(driver, 5);
		SeleniumUtils.setValueToElement(driver, OpargoApp_PageObjects.enterProgrameName, FileReaderManager.getInstance().getConfigReader().readFromProperties("progarme"));
	}
	public static void userAbleToSelectTheGoalOfProgrameInTheDropdon() {
		SeleniumUtils.safeWait(driver, 5);
		SeleniumUtils.clickElementbyWebElementWithOutSendKeys(driver, OpargoApp_PageObjects.clickGoalProgrameDropdown);
		SeleniumUtils.safeWait(driver, 5);
		SeleniumUtils.clickElementbyWebElementWithOutSendKeys(driver, OpargoApp_PageObjects.selectGoalProgrameDropdown);
	}
	public static void userAbleToSelectTheTextTimeInTheDropdown() {
		SeleniumUtils.safeWait(driver, 5);
		SeleniumUtils.clickElementbyWebElementWithOutSendKeys(driver, OpargoApp_PageObjects.clickTextTimeDropdown);
		SeleniumUtils.safeWait(driver, 5);
		SeleniumUtils.clickElementbyWebElementWithOutSendKeys(driver, OpargoApp_PageObjects.selectTextTimeDropdown);
	}
	public static void userAbleToEnterTheTextAllocation() throws IOException {
		SeleniumUtils.safeWait(driver, 5);
		SeleniumUtils.setValueToElement(driver, OpargoApp_PageObjects.enterTextAllocation, FileReaderManager.getInstance().getConfigReader().readFromProperties("textAllocation"));
	}
	public static void userAbleToClickOnCreateProgrameButton() {
		SeleniumUtils.safeWait(driver, 5);
		SeleniumUtils.clickElementbyWebElementWithOutSendKeys(driver, OpargoApp_PageObjects.clickOnCreatePrograme);
	}
	public static void userAbleToSearchTheCreatedProgrameInTheSmartReach() throws IOException {
		SeleniumUtils.safeWait(driver, 5);
		SeleniumUtils.setValueToElement(driver, OpargoApp_PageObjects.SearchTab, FileReaderManager.getInstance().getConfigReader().readFromProperties("search"));
	}
	public static void userAbleToSelectTheCreatedSmartReachPrograme() {
		SeleniumUtils.safeWait(driver, 5);
		SeleniumUtils.clickElementbyWebElementWithOutSendKeys(driver, OpargoApp_PageObjects.selectCreatedSamrtREachPrpgrame);
	}
	public static void userAbleToClickOnProgrameDetailsOptionInTheActionsTab() {
		SeleniumUtils.safeWait(driver, 5);
		SeleniumUtils.clickElementbyWebElementWithOutSendKeys(driver, OpargoApp_PageObjects.clickonProgrameDetailsOption);
	}
	public static void userAbleToClickOnCriteriaOption() {
		SeleniumUtils.safeWait(driver, 5);
		SeleniumUtils.clickElementbyWebElementWithOutSendKeys(driver, OpargoApp_PageObjects.clickonCriteriaOption);
	}
	public static void userAbleToSelectOnCriteriaOptions() {
		SeleniumUtils.safeWait(driver, 5);
		SeleniumUtils.clickElementbyWebElementWithOutSendKeys(driver, OpargoApp_PageObjects.SelectAppointmentTypeOption);
		SeleniumUtils.clickElementbyWebElementWithOutSendKeys(driver, OpargoApp_PageObjects.selectGenderOption);
		SeleniumUtils.clickElementbyWebElementWithOutSendKeys(driver, OpargoApp_PageObjects.selectInsurencePlan);
	}
	public static void userAbleToClickOnNextButton() {
		SeleniumUtils.safeWait(driver, 5);
		SeleniumUtils.clickElementbyWebElementWithOutSendKeys(driver, OpargoApp_PageObjects.clickOnNextButton);
	}
	public static void userAbleToEditTheAppointmentTypeAndSelectOnAppointmentType() {
		SeleniumUtils.safeWait(driver, 5);
		SeleniumUtils.clickElementbyWebElementWithOutSendKeys(driver, OpargoApp_PageObjects.clickEditAppointmentType);
		SeleniumUtils.safeWait(driver, 5);
		SeleniumUtils.clickElementbyWebElementWithOutSendKeys(driver, OpargoApp_PageObjects.selectAppointmentType);
	}
	public static void userAbleToClickOnSaveButton() {
		SeleniumUtils.safeWait(driver, 5);
		SeleniumUtils.clickElementbyWebElementWithOutSendKeys(driver, OpargoApp_PageObjects.ClickonSaveButton);
	}
	public static void userAbleToClickOnSAveButtonInSmartEnginePage() {
		SeleniumUtils.safeWait(driver, 5);
		SeleniumUtils.clickElementbyWebElementWithOutSendKeys(driver, OpargoApp_PageObjects.clickOnSave);
	}
	public static void userAbleToEditInsurencePlansAndSelectInsurencePlans() {
		SeleniumUtils.safeWait(driver, 5);
		SeleniumUtils.clickElementbyWebElementWithOutSendKeys(driver, OpargoApp_PageObjects.clickEditInsurencePlans);
		SeleniumUtils.safeWait(driver, 5);
		SeleniumUtils.clickElementbyWebElementWithOutSendKeys(driver, OpargoApp_PageObjects.selectInsurencePlans);
	}
	public static void userAbleToEditGenderAndSelectGender() {
		SeleniumUtils.safeWait(driver, 5);
		SeleniumUtils.clickElementbyWebElementWithOutSendKeys(driver, OpargoApp_PageObjects.clickEditGender);
		SeleniumUtils.safeWait(driver, 5);
		SeleniumUtils.clickElementbyWebElementWithOutSendKeys(driver, OpargoApp_PageObjects.selectGender);
	}
	public static void userAbleToClickOnScheduledActionButtonAndSelectScheduleAction() {
		SeleniumUtils.safeWait(driver, 5);
		SeleniumUtils.clickElementbyWebElementWithOutSendKeys(driver, OpargoApp_PageObjects.clickOnScheduledAcion);
		SeleniumUtils.safeWait(driver, 5);
		SeleniumUtils.clickElementbyWebElementWithOutSendKeys(driver, OpargoApp_PageObjects.selectScheduleAction);
	}
	public static void userAbleToEditTheLocationAndSelectTheLocation() {
		SeleniumUtils.safeWait(driver, 5);
		SeleniumUtils.clickElementbyWebElementWithOutSendKeys(driver, OpargoApp_PageObjects.editAppointmentType);
		SeleniumUtils.safeWait(driver, 3);
		SeleniumUtils.clickElementbyWebElementWithOutSendKeys(driver, OpargoApp_PageObjects.selectAppointmentTypeOption);
		SeleniumUtils.safeWait(driver, 3);
		SeleniumUtils.clickElementbyWebElementWithOutSendKeys(driver, OpargoApp_PageObjects.saveOption);
		SeleniumUtils.safeWait(driver, 3);
		SeleniumUtils.clickElementbyWebElementWithOutSendKeys(driver, OpargoApp_PageObjects.editLocation);
		SeleniumUtils.safeWait(driver, 3);
		SeleniumUtils.clickElementbyWebElementWithOutSendKeys(driver, OpargoApp_PageObjects.selectLocationInScheduleValues);
	}
	public static void userAbleToClickOnSaveOption() {
		SeleniumUtils.safeWait(driver, 5);
		SeleniumUtils.clickElementbyWebElementWithOutSendKeys(driver, OpargoApp_PageObjects.saveOPtion);
	}
	public static void userAbleToClickOnTextMessageButton() {
		SeleniumUtils.safeWait(driver, 5);
		SeleniumUtils.clickElementbyWebElementWithOutSendKeys(driver, OpargoApp_PageObjects.clickOnTextMessage);
	}
	public static void userAbleToEnterTheTextAfterLinkTextarea() throws IOException {
		SeleniumUtils.safeWait(driver, 5);
		SeleniumUtils.setValueToElementWithoutClearText(driver, OpargoApp_PageObjects.enterText, FileReaderManager.getInstance().getConfigReader().readFromProperties("textarea"));
	}
	public static void userAbleToClickOnCloseButton() {
		SeleniumUtils.safeWait(driver, 5);
		SeleniumUtils.clickElementbyWebElementWithOutSendKeys(driver, OpargoApp_PageObjects.clickcloseButton);
	}
	public static void userAbleToClickAndChangeStatusOfCreatedPrograme() {
		SeleniumUtils.safeWait(driver, 3);
		SeleniumUtils.clickElementbyWebElementWithOutSendKeys(driver, OpargoApp_PageObjects.clickOnStatus);
		SeleniumUtils.safeWait(driver, 3);
		SeleniumUtils.clickElementbyWebElementWithOutSendKeys(driver, OpargoApp_PageObjects.selectandChangeTheStatus);
	}
	public static void userAbleToSelectTheProgrameInfoOptionInTheActionTab() {
		SeleniumUtils.safeWait(driver, 5);
		SeleniumUtils.clickElementbyWebElementWithOutSendKeys(driver, OpargoApp_PageObjects.selectCreatedSamrtREachPrpgrame);
		SeleniumUtils.safeWait(driver, 3);
		SeleniumUtils.clickElementbyWebElementWithOutSendKeys(driver, OpargoApp_PageObjects.selectTheProgrameInfoOption);
	}
	public static void userAbleToClickOnEditProgrameButton() {
		SeleniumUtils.safeWait(driver, 5);
		SeleniumUtils.clickElementbyWebElementWithOutSendKeys(driver, OpargoApp_PageObjects.EditProgrameButton);
	}
	public static void userAbleToDeleteTheCreatedProgrameInTheActionTab() {
		SeleniumUtils.safeWait(driver, 5);
		SeleniumUtils.clickElementbyWebElementWithOutSendKeys(driver, OpargoApp_PageObjects.selectCreatedSamrtREachPrpgrame);
		SeleniumUtils.safeWait(driver, 5);
		SeleniumUtils.clickElementbyWebElementWithOutSendKeys(driver, OpargoApp_PageObjects.DeleteCreatedePrograme);
		SeleniumUtils.safeWait(driver, 3);
		SeleniumUtils.clickElementbyWebElementWithOutSendKeys(driver, OpargoApp_PageObjects.clickOnYesButton);
	}
	public static void userAbleToClickOnNextButtonInScheduledActionPage() {
		SeleniumUtils.safeWait(driver, 5);
		SeleniumUtils.clickElementbyWebElementWithOutSendKeys(driver, OpargoApp_PageObjects.againclickOnNextButton);
	}
	public static void userAbleToClickOnAgainSaveButton() {
		SeleniumUtils.safeWait(driver, 5);
		SeleniumUtils.clickElementbyWebElementWithOutSendKeys(driver, OpargoApp_PageObjects.againclickOnsaveButton);
	}
	public static void userAbleTOClickOnAgainSAveButton() {
		SeleniumUtils.safeWait(driver, 5);
		SeleniumUtils.clickElementbyWebElementWithOutSendKeys(driver, OpargoApp_PageObjects.againClickOnSAveBUtton);
	}
	
	
	
	

}
